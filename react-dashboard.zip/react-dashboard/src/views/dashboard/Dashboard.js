import React from 'react'

import avatar1 from 'src/assets/images/avatars/1.jpg'


const Dashboard = () => {



  return (
    <>
      <h1>Main Dashboard</h1>
    </>
  )
}

export default Dashboard
