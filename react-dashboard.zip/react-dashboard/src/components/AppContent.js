import React, { Suspense } from 'react'


// routes config
import routes from '../routes'

const AppContent = () => {
  return (
<></>
  )
}

export default React.memo(AppContent)
